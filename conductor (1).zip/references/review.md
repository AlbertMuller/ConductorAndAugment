# Review Protocol

Review a Conductor track or current changes as a principal-level code review.

## Preconditions

- Resolve and verify `tracks.md`, `product.md`, `product-guidelines.md`, `tech-stack.md`, and `workflow.md`.
- If setup artifacts are missing, stop and report that Conductor is not set up.

## Scope selection

1. If the user specifies a target scope, use it.
2. Otherwise look for an in-progress track and ask whether to review it.
3. If no in-progress track is suitable, ask what should be reviewed.
4. Confirm the review scope before proceeding.

## Context loading

1. Read:
   - `product-guidelines.md`
   - `tech-stack.md`
   - every markdown file under `conductor/code_styleguides/` if present
2. Treat `conductor/code_styleguides/` as the enforceable, project-local copy of the styleguide templates selected during setup.
3. If reviewing a track:
   - read its `plan.md`
   - read its `spec.md` if available
   - determine the relevant revision range from recorded commits or current repository state
4. Load diffs using a strategy proportional to size:
   - small and medium changes can be reviewed in one pass
   - large changes should be reviewed file by file

## Checks

Evaluate the changes against:
- plan compliance
- spec compliance
- product guidelines
- code style guides
- correctness and safety
- security risks
- testing presence and plausibility
- actual test execution where feasible

## Output format

Lead with findings ordered by severity.
For each finding include:
- severity
- file path and line reference when available
- why it matters
- a concrete fix direction

If no findings exist, state that explicitly and mention any residual verification gaps.

## Decision phase

If issues are found, present the practical next action:
- apply fixes
- stop for manual fixes
- accept the risk and proceed

If review-related edits are made, update the track plan if appropriate and commit only when that matches the repository workflow.
