# New Track Protocol

Create a new Conductor track for a feature, bug, chore, or refactor.

## Preconditions

- Resolve and verify `product.md`, `tech-stack.md`, and `workflow.md`.
- If these are missing, stop and tell the user to run Conductor setup first.

## Procedure

1. Load project context from the resolved Conductor files.
2. Obtain the track description:
   - Use the user-provided description if it already exists.
   - Otherwise ask for a brief description.
3. Infer the track type from the description instead of asking the user to classify it.
4. Create `spec.md` interactively:
   - Ask context-aware questions tailored to the track type.
   - For feature work, clarify behavior, interactions, inputs, outputs, and acceptance criteria.
   - For bug or chore work, clarify scope, reproduction, impact, and success conditions.
   - Draft `spec.md` with sections such as Overview, Functional Requirements, Non-Functional Requirements, Acceptance Criteria, and Out of Scope.
   - Revise until approved.
5. Create `plan.md` from the approved specification and the workflow:
   - Read `conductor/workflow.md`.
   - Break the track into phases, tasks, and sub-tasks.
   - Use `[ ]` for every pending task and sub-task.
   - Encode workflow-driven steps such as TDD where required.
   - Inject phase completion verification tasks when the workflow requires them.
   - Revise until approved.
6. Before writing the track, list existing track directories and prevent duplicate short names.
7. Generate a unique track id using `shortname_YYYYMMDD`.
8. Create the new track directory and write:
   - `spec.md`
   - `plan.md`
   - `metadata.json`
   - `index.md`
9. Append the new track entry to `conductor/tracks.md`.
10. If the repo workflow uses commits for plan operations, commit the new track artifacts and registry entry.

## Output expectations

- The track directory is complete and self-navigable through `index.md`.
- The registry entry in `tracks.md` points at the correct relative path.
- The plan structure reflects the actual workflow policy, not a generic todo list.
