# Implement Protocol

Implement a Conductor track by executing the approved plan in order.

## Preconditions

- Resolve and verify `product.md`, `tech-stack.md`, `workflow.md`, and `tracks.md`.
- If setup artifacts are missing, stop and tell the user to run Conductor setup first.

## Track selection

1. If the user names a track, match it against the track registry and confirm the selection.
2. Otherwise choose the next incomplete track in `conductor/tracks.md` and confirm before proceeding.
3. If all tracks are complete, stop and report that no incomplete track remains.

## Procedure

1. Mark the selected track as in progress in `conductor/tracks.md`.
2. Load:
   - the track specification
   - the track plan
   - the project workflow
3. Treat `conductor/workflow.md` as the runtime source of truth for task execution.
4. Work tasks sequentially. For each task:
   - Mark the task as in progress in `plan.md`.
   - Execute the workflow steps required for that task, including red/green/refactor if TDD is required.
   - Run the relevant tests, linting, and coverage checks.
   - Update the task to complete only after the workflow gates pass.
   - Record commit SHAs in `plan.md` when the workflow requires them.
5. When a phase completes:
   - Execute the phase verification and checkpoint procedure defined in `conductor/workflow.md`.
   - Produce a manual verification plan for the user and wait for confirmation where required.
   - Create checkpoint commits and record checkpoint SHAs in the plan when the workflow requires it.
6. When all tasks complete:
   - Mark the track complete in `conductor/tracks.md`.
   - Commit track-state changes if the repository workflow expects them.
7. Synchronize project-level documentation when the completed track changes product behavior, project guidance, or the tech stack:
   - propose changes to `product.md`
   - propose changes to `tech-stack.md`
   - change `product-guidelines.md` only for strategic shifts
8. Offer cleanup actions for the completed track:
   - review
   - archive
   - delete
   - skip

## Guardrails

- Do not skip plan updates.
- Do not mark work complete without running the required verification.
- Stop and report persistent failures instead of silently pushing through them.
