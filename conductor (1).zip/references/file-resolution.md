# Universal File Resolution Protocol

Use this protocol before any Conductor command-specific logic.

## Goal

Resolve Conductor artifacts reliably from either project scope or track scope.

## Project scope

1. Use `conductor/index.md` as the primary project index.
2. If the index exists, read it and look for the relevant linked artifact.
3. Resolve linked paths relative to the directory containing the index.
4. Verify the resolved path exists on disk.
5. If the index is missing or the link is absent, fall back to the standard default paths below.

## Track scope

1. Resolve the tracks registry from project scope.
2. Read `conductor/tracks.md` and find the entry for the relevant track.
3. Follow the linked track directory, then use `<track_dir>/index.md`.
4. Resolve linked paths relative to the track index directory.
5. If the track is not yet registered or the link is missing, fall back to `conductor/tracks/<track_id>/...`.
6. Verify the resolved path exists on disk.

## Standard default paths

Project artifacts:
- Product Definition: `conductor/product.md`
- Product Guidelines: `conductor/product-guidelines.md`
- Tech Stack: `conductor/tech-stack.md`
- Workflow: `conductor/workflow.md`
- Tracks Registry: `conductor/tracks.md`
- Tracks Directory: `conductor/tracks/`

Track artifacts:
- Specification: `conductor/tracks/<track_id>/spec.md`
- Implementation Plan: `conductor/tracks/<track_id>/plan.md`
- Metadata: `conductor/tracks/<track_id>/metadata.json`
- Track Index: `conductor/tracks/<track_id>/index.md`

## Resolution discipline

- Prefer the index file when it exists because it is the source of navigational truth.
- Use semantically matching links, not just exact labels, when reading indexes.
- If a required artifact cannot be resolved, stop the current Conductor operation and report the missing dependency.
