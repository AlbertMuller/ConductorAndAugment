# Revert Protocol

Revert Conductor work by logical intent rather than by raw commit guesswork.

## Preconditions

- Resolve and verify `conductor/tracks.md`.
- If the registry is missing or empty, stop and report that Conductor is not set up or has no track history to revert.

## Objective

Map a requested track, phase, or task back to the actual git commits that implemented and tracked it, then confirm a precise revert plan before changing anything.

## Procedure

1. Identify the revert target:
   - use the user-provided target if present, then confirm it
   - otherwise inspect the tracks registry and track plans for the most relevant in-progress or recently completed items, then ask the user to choose
2. Once the logical target is confirmed, inspect git history to find all related commits:
   - implementation commits
   - plan-update commits
   - track-creation commit when reverting an entire track
3. If a recorded SHA no longer exists, search for a likely rewritten equivalent and ask the user to confirm before using it.
4. Compile the final revert set and inspect it for complications such as merge commits or suspicious duplicates.
5. Present the execution plan clearly:
   - target being reverted
   - commits involved
   - revert order
   - expected side effects
6. Ask for explicit approval before executing any revert.
7. If approved:
   - run reverts from newest to oldest
   - stop immediately on conflicts and report manual resolution steps
   - verify that the relevant plan or registry state reflects the reverted work
   - repair plan state if needed and commit that correction when appropriate

## Guardrails

- Never perform destructive history edits when a reversible `git revert` flow is appropriate.
- Never infer the target silently when the revert scope is ambiguous.
- Prefer a slower, explained reconciliation over a risky shortcut.
