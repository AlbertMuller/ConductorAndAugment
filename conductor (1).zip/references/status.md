# Status Protocol

Report Conductor progress from real artifacts, not memory.

## Preconditions

- Resolve and verify `tracks.md`, `product.md`, `tech-stack.md`, and `workflow.md`.
- If setup artifacts are missing, stop and report that Conductor is not set up.

## Procedure

1. Read the tracks registry.
2. Parse track entries in either supported format:
   - `- [ ] **Track: ...**`
   - `## [ ] Track: ...`
3. For each registered track, resolve and read its `plan.md`.
4. Parse plan structure to identify:
   - phases
   - total tasks
   - completed tasks
   - in-progress tasks
   - pending tasks
   - explicit blockers
5. Produce a concise status report that includes:
   - current timestamp
   - overall project status
   - current track, phase, and task in progress
   - next pending action
   - blockers
   - phase count
   - task count
   - progress as completed over total, with percentage

## Reporting discipline

- Prefer precise counts over vague summaries.
- If the registry or plans are malformed, say so clearly instead of guessing.
