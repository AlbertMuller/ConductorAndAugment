---
name: conductor-framework
description: >
  Run the full Conductor context-driven development lifecycle for a repository:
  setup project context, create a new track with spec and plan artifacts,
  implement the next planned task, report status, review work against the plan
  and standards, and revert track-scoped work safely. Use this whenever the
  user mentions Conductor, track-based planning, spec-first implementation,
  `conductor/` artifacts, or asks for setup/new track/implement/status/review/revert
  behavior even if they do not explicitly name the skill.
---

# Conductor Framework

Use this skill as the operating manual for Conductor-style development inside Codex.

## What this skill governs

Conductor treats repository context as a managed artifact:
- `conductor/index.md`
- `conductor/product.md`
- `conductor/product-guidelines.md`
- `conductor/tech-stack.md`
- `conductor/workflow.md`
- `conductor/tracks.md`
- `conductor/tracks/<track_id>/spec.md`
- `conductor/tracks/<track_id>/plan.md`
- `conductor/tracks/<track_id>/metadata.json`
- `conductor/tracks/<track_id>/index.md`

Keep these files synchronized with the real state of the project.

This skill also bundles a reusable styleguide library in `templates/code_styleguides/`.
Use those files during setup when choosing which guides to copy into the project's
own `conductor/code_styleguides/` directory.

It also bundles the default workflow scaffold at `templates/workflow.md`.
Use that file during setup when seeding the project's `conductor/workflow.md`.

## When to activate

Activate this skill when the user asks for any of the following:
- Conductor setup or project initialization
- Creating or planning a new track
- Implementing the next planned unit of work
- Checking Conductor status
- Reviewing completed or in-progress track work
- Reverting work by track, phase, or task
- Spec-first or plan-driven execution using `conductor/` artifacts

If the user intent is ambiguous, ask one concise clarifying question and then dispatch.

## Execution rules

1. Start with [`references/file-resolution.md`](./references/file-resolution.md).
2. Resolve the user request into one operation:
   - `setup`
   - `newTrack`
   - `implement`
   - `status`
   - `review`
   - `revert`
3. Load only the matching protocol file:
   - [`references/setup.md`](./references/setup.md)
   - [`references/newTrack.md`](./references/newTrack.md)
   - [`references/implement.md`](./references/implement.md)
   - [`references/status.md`](./references/status.md)
   - [`references/review.md`](./references/review.md)
   - [`references/revert.md`](./references/revert.md)
4. Follow the protocol sequentially. Do not skip required checkpoints.
5. Validate each important tool call. If a required read, write, test, or git action fails, stop that operation, report the failure clearly, and wait for user direction.

## Codex adaptation rules

- Prefer direct tool execution over narrating hypothetical commands.
- When a protocol requires user confirmation, ask plainly in the conversation with one concise question.
- Preserve Conductor discipline even if the user asks for implementation quickly. The framework is intentionally spec-first and plan-first.
- Treat `conductor/workflow.md` as the runtime rulebook for implementation details such as TDD, coverage, commit cadence, and checkpoint behavior.
- During `setup`, select styleguides from the bundled `templates/code_styleguides/` library and copy the chosen guides into `conductor/code_styleguides/`.
- During `setup`, seed `conductor/workflow.md` from the bundled `templates/workflow.md` template before applying any user customizations.
- During `implement` and `review`, treat the project's `conductor/code_styleguides/` files as the enforceable local standards.
- Prefer non-interactive commands and repository-local evidence over assumptions.
- Do not invent alternate artifact names when standard Conductor paths apply.

## Operational expectations

- `setup` creates and populates the project-level Conductor context.
- `newTrack` creates a new track folder, specification, implementation plan, and registry entry.
- `implement` works the current plan in order, updating statuses as tasks move from pending to in-progress to complete.
- `status` summarizes real progress from `conductor/tracks.md` and track plans.
- `review` checks the implementation against the plan, guidelines, tests, and changed code.
- `revert` maps logical Conductor work back to actual git commits before proposing any destructive action.

## Enforcement

- Keep plan status markers consistent.
- Keep track metadata aligned with the actual track state.
- Keep project-level docs synchronized when completed track work changes product behavior or the tech stack.
- Prefer protocol compliance over speed shortcuts.
